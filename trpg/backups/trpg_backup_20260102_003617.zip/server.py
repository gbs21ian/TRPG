import os
import json
import hashlib
from flask import Flask, request, jsonify, send_from_directory

app = Flask(__name__)

# 데이터 저장 경로
DATA_DIR = os.path.join(os.getcwd(), 'saves')
if not os.path.exists(DATA_DIR):
    os.makedirs(DATA_DIR)

def get_account_file(api_key):
    """API Key를 해싱하여 고유한 파일명을 생성합니다."""
    # 실제 운영 환경에서는 API Key를 직접 사용하는 것보다 더 안전한 인증 방식이 필요하지만,
    # 로컬 개인 프로젝트 요구사항에 맞춰 API Key를 식별자로 사용합니다.
    hashed = hashlib.sha256(api_key.encode('utf-8')).hexdigest()
    return os.path.join(DATA_DIR, f"{hashed}.json")

@app.route('/')
def serve_index():
    return send_from_directory('.', 'trpg.html')

@app.route('/<path:path>')
def serve_static(path):
    return send_from_directory('.', path)

@app.route('/api/login', methods=['POST'])
def login():
    """
    API Key를 받아 계정을 확인하고 저장된 게임 목록을 반환합니다.
    계정이 없으면 파일을 생성할 준비를 합니다(실제 생성은 저장 시).
    """
    data = request.json
    api_key = data.get('apiKey')
    if not api_key:
        return jsonify({"error": "API Key is required"}), 400

    filepath = get_account_file(api_key)
    
    if not os.path.exists(filepath):
        # 신규 유저
        return jsonify({"saves": [], "message": "New account created"})
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            saves = json.load(f)
        return jsonify({"saves": saves})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/save', methods=['POST'])
def save_game():
    """
    게임을 저장합니다.
    """
    data = request.json
    api_key = data.get('apiKey')
    save_data = data.get('saveData')
    
    if not api_key or not save_data:
        return jsonify({"error": "Invalid data"}), 400

    filepath = get_account_file(api_key)
    
    saves = []
    if os.path.exists(filepath):
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                saves = json.load(f)
        except:
            saves = []

    # 기존 세이브 덮어쓰기 (ID가 같은 경우) 또는 새로 추가
    save_id = save_data.get('id')
    existing_index = next((i for i, s in enumerate(saves) if s.get('id') == save_id), -1)
    
    if existing_index >= 0:
        saves[existing_index] = save_data
    else:
        saves.append(save_data)
        
    # 최신순 정렬 (timestamp 기준 내림차순)
    saves.sort(key=lambda x: x.get('timestamp', 0), reverse=True)

    try:
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(saves, f, ensure_ascii=False, indent=2)
        return jsonify({"success": True, "saves": saves})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/delete', methods=['POST'])
def delete_save():
    """
    특정 세이브 파일을 삭제합니다.
    """
    data = request.json
    api_key = data.get('apiKey')
    save_id = data.get('saveId')

    if not api_key or not save_id:
        return jsonify({"error": "Invalid data"}), 400

    filepath = get_account_file(api_key)
    if not os.path.exists(filepath):
        return jsonify({"error": "Account not found"}), 404

    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            saves = json.load(f)
        
        saves = [s for s in saves if s.get('id') != save_id]
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(saves, f, ensure_ascii=False, indent=2)
            
        return jsonify({"success": True, "saves": saves})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    print("Starting TRPG Server on http://localhost:8080")
    app.run(port=8080, debug=True)
